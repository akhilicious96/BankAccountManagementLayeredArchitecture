package com.cg.bam.exception;

public class BankAccountException extends Exception{
	public BankAccountException(String message){
		super(message);
	}
}
